#!/usr/bin/env python3
# 가챠 게임 메이커 PC 서버
# - 내 PC에서 게임을 띄우고, Cloudflare 임시 주소(trycloudflare)로 휴대폰에서 접속해요.
# - 게임 데이터(진행·그림)를 이 PC의 ggm-data 폴더에 저장해요.
# - AI 요청을 PC가 대신 보내서 CORS/Origin 문제 없이, 내 PC의 ComfyUI·Ollama도 휴대폰에서 쓸 수 있어요.
# 필요: Python 3.8 이상. 창을 닫으면 주소가 사라져요(다음 실행 때 새 주소 + 새 QR).
import base64, hashlib, http.server, json, os, platform, re, secrets, shutil, socket, socketserver, stat, subprocess, sys, tarfile, threading, time, urllib.error, urllib.parse, urllib.request, webbrowser

SERVER_VER = '2026.10.08.19'
PORT = int(os.environ.get('GGM_PORT', '8790'))
REPO = os.environ.get('GGM_REPO', 'jjhk0803/gacha-game-maker')
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'ggm-data')
WWW = os.path.join(HERE, 'www')
BLOBS = os.path.join(DATA, 'blobs')
os.makedirs(BLOBS, exist_ok=True); os.makedirs(os.path.join(WWW, 'icons'), exist_ok=True)

KEYF = os.path.join(DATA, 'key.txt')
if not os.path.exists(KEYF):
    open(KEYF, 'w').write(secrets.token_urlsafe(18))
KEY = open(KEYF).read().strip()
PUBLIC = {'url': ''}
LEASE = {'id': '', 'name': '', 'at': 0, 'seen': 0, 'away': True, 'want': None}
LEASE_LOCK = threading.Lock()

def log(*a): print(*a, flush=True)

# ---------- 게임 파일 받기 (항상 최신) ----------
FILES = ['index.html', 'manifest.webmanifest', 'sw.js', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png', 'icons/apple-touch-icon.png']
def update_www():
    ok = 0
    for f in FILES:
        url = f'https://raw.githubusercontent.com/{REPO}/main/www/{f}?t={int(time.time())}'
        try:
            data = urllib.request.urlopen(url, timeout=30).read()
            open(os.path.join(WWW, f), 'wb').write(data); ok += 1
        except Exception as e:
            if not os.path.exists(os.path.join(WWW, f)): log('  ! 받지 못함:', f, e)
    log(f'게임 파일 확인 완료 ({ok}/{len(FILES)} 최신)')

# ---------- HTTP 서버 ----------
HOP = {'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailers', 'transfer-encoding', 'upgrade', 'host', 'origin', 'referer', 'cookie', 'content-length', 'x-ggm-key', 'accept-encoding'}
class H(http.server.SimpleHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def __init__(self, *a, **k): super().__init__(*a, directory=WWW, **k)
    def log_message(self, *a): pass
    def cors(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
        self.send_header('Access-Control-Expose-Headers', '*')
    def end_headers(self):
        if self.path.startswith('/api/'): self.cors()
        super().end_headers()
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Content-Length', '0'); self.end_headers()
    def authed(self):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        k = self.headers.get('X-GGM-Key') or (q.get('k') or [''])[0]
        return secrets.compare_digest(k, KEY)
    def jsend(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header('Content-Type', 'application/json; charset=utf-8'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        return self.rfile.read(n) if n else b''
    def do_GET(self):
        if self.path.startswith('/api/'): return self.api('GET')
        if self.path.startswith('/connect'): return self.connect_page()
        p = urllib.parse.urlparse(self.path).path
        if p in ('/', ''): self.path = '/index.html'
        return super().do_GET()
    def do_POST(self): return self.api('POST') if self.path.startswith('/api/') else self.send_error(404)
    def do_PUT(self): return self.api('PUT') if self.path.startswith('/api/') else self.send_error(404)
    def do_DELETE(self): return self.api('DELETE') if self.path.startswith('/api/') else self.send_error(404)
    def do_PATCH(self): return self.api('PATCH') if self.path.startswith('/api/') else self.send_error(404)
    def connect_page(self):
        if self.client_address[0] not in ('127.0.0.1', '::1'): return self.send_error(403)
        url = PUBLIC['url']; lan = lan_url()
        html = f'''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>가챠 게임 메이커 PC 서버</title>
<style>body{{font-family:sans-serif;background:#0b0d14;color:#eee;text-align:center;padding:30px}}a{{color:#ffb400;word-break:break-all}}#q{{background:#fff;display:inline-block;padding:14px;margin:16px}}small{{color:#999}}</style>
<h1>가챠 게임 메이커 · PC 서버</h1><p>휴대폰 카메라로 QR을 찍으면 바로 연결돼요.</p>
<div id="q"></div><p><a href="{url}">{url or '(외부 주소 준비 중… 새로고침 해 보세요)'}</a></p>
<p><small>같은 와이파이라면: <a href="{lan}">{lan}</a></small></p>
<p><small>이 창(검은 창)을 닫으면 주소가 사라져요. 주소에는 비밀 키가 들어 있으니 다른 사람에게 보내지 마세요.</small></p>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>if(window.QRCode&&"{url}")new QRCode(document.getElementById("q"),{{text:"{url}",width:240,height:240}});</script>'''.encode()
        self.send_response(200); self.send_header('Content-Type', 'text/html; charset=utf-8'); self.send_header('Content-Length', str(len(html))); self.end_headers(); self.wfile.write(html)
    def api(self, m):
        path = urllib.parse.urlparse(self.path).path
        if path == '/api/hello' and m == 'GET': return self.jsend(200, {'ok': True, 'app': 'ggm-pc', 'ver': SERVER_VER, 'auth': self.authed(), 'host': socket.gethostname()})
        if not self.authed(): return self.jsend(401, {'error': 'bad key'})
        try:
            if path == '/api/proxy': return self.proxy(m)
            if path == '/api/update' and m == 'POST': self.body(); update_www(); return self.jsend(200, {'ok': True})
            if path == '/api/store/state':
                f = os.path.join(DATA, 'state.json')
                if m == 'GET':
                    if not os.path.exists(f): return self.jsend(404, {'error': 'none'})
                    b = open(f, 'rb').read(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
                b = self.body(); json.loads(b); tmp = f + '.tmp'; open(tmp, 'wb').write(b); os.replace(tmp, f)
                if os.path.exists(f):
                    bk = os.path.join(DATA, 'history'); os.makedirs(bk, exist_ok=True); shutil.copy(f, os.path.join(bk, time.strftime('state-%Y%m%d-%H%M%S.json')))
                    hs = sorted(os.listdir(bk));  [os.remove(os.path.join(bk, x)) for x in hs[:-20]]
                return self.jsend(200, {'ok': True})
            if path == '/api/lease':
                # 한 번에 한 기기만 플레이: claim(차지) · beat(살아 있음) · want(넘겨 달라) · give(넘겨 줌) · away(자리 비움)
                with LEASE_LOCK:
                    now = time.time() * 1000
                    if m == 'POST':
                        j = json.loads(self.body() or b'{}'); op = j.get('op'); did = str(j.get('id', ''))[:64]; nm = str(j.get('name', ''))[:40]
                        if op == 'claim': LEASE.update({'id': did, 'name': nm, 'at': now, 'seen': now, 'away': False, 'want': None})
                        elif op == 'beat' and LEASE['id'] == did: LEASE.update({'seen': now, 'away': False})
                        elif op == 'want': LEASE['want'] = {'id': did, 'name': nm, 'at': now}
                        elif op == 'give' and LEASE['id'] == did and LEASE.get('want'): w = LEASE['want']; LEASE.update({'id': w['id'], 'name': w['name'], 'at': now, 'seen': now, 'away': False, 'want': None})
                        elif op == 'away' and LEASE['id'] == did: LEASE.update({'away': True, 'seen': now})
                        elif op == 'free' and LEASE['id'] == did: LEASE.update({'id': '', 'name': '', 'away': True, 'want': None})
                    return self.jsend(200, dict(LEASE, now=now))
            if path == '/api/store/list': return self.jsend(200, {'blobs': os.listdir(BLOBS)})
            mm = re.match(r'^/api/store/blob/([0-9a-f]{64})$', path)
            if mm:
                f = os.path.join(BLOBS, mm.group(1))
                if m == 'GET':
                    if not os.path.exists(f): return self.jsend(404, {'error': 'none'})
                    b = open(f, 'rb').read(); self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
                j = json.loads(self.body()); data = base64.b64decode(j['content'])
                if hashlib.sha256(data).hexdigest() != mm.group(1): return self.jsend(400, {'error': 'hash mismatch'})
                open(f, 'wb').write(data); return self.jsend(200, {'ok': True})
            return self.jsend(404, {'error': 'unknown'})
        except Exception as e:
            try: return self.jsend(500, {'error': str(e)})
            except Exception: pass
    def proxy(self, m):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query); u = (q.get('u') or [''])[0]
        t = urllib.parse.urlparse(u)
        if t.scheme not in ('http', 'https') or not t.netloc: return self.jsend(400, {'error': 'bad url'})
        hdr = {k: v for k, v in self.headers.items() if k.lower() not in HOP}
        data = self.body() if m in ('POST', 'PUT', 'PATCH', 'DELETE') else None
        if data is not None and not data: data = None if m == 'DELETE' else b''
        req = urllib.request.Request(u, data=data, headers=hdr, method=m)
        try: r = urllib.request.urlopen(req, timeout=900)
        except urllib.error.HTTPError as e: r = e
        except Exception as e: return self.jsend(502, {'error': 'PC에서 연결하지 못했어요: ' + str(e)})
        b = r.read()
        self.send_response(r.status if hasattr(r, 'status') else r.code)
        for k, v in r.headers.items():
            if k.lower() not in HOP and not k.lower().startswith('access-control') and k.lower() != 'content-encoding': self.send_header(k, v)
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

class Srv(socketserver.ThreadingMixIn, http.server.HTTPServer): daemon_threads = True; allow_reuse_address = True

def lan_url():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('8.8.8.8', 80)); ip = s.getsockname()[0]; s.close()
        return f'http://{ip}:{PORT}/?pc={KEY}'
    except Exception: return f'http://127.0.0.1:{PORT}/?pc={KEY}'

# ---------- Cloudflare 임시 주소 ----------
def cloudflared_path():
    exe = 'cloudflared.exe' if os.name == 'nt' else 'cloudflared'
    p = shutil.which('cloudflared') or os.path.join(HERE, exe)
    if os.path.exists(p): return p
    sysn, mach = platform.system().lower(), platform.machine().lower()
    arch = 'arm64' if mach in ('arm64', 'aarch64') else 'amd64'
    base = 'https://github.com/cloudflare/cloudflared/releases/latest/download/'
    log('cloudflared 받는 중… (처음 한 번)')
    try:
        if sysn == 'windows': urllib.request.urlretrieve(base + f'cloudflared-windows-{arch}.exe', p)
        elif sysn == 'darwin':
            tg = os.path.join(HERE, 'cf.tgz'); urllib.request.urlretrieve(base + f'cloudflared-darwin-{arch}.tgz', tg)
            with tarfile.open(tg) as t: t.extractall(HERE)
            os.remove(tg)
        else: urllib.request.urlretrieve(base + f'cloudflared-linux-{arch}', p)
        if os.name != 'nt': os.chmod(p, os.stat(p).st_mode | stat.S_IEXEC)
        return p
    except Exception as e:
        log('  ! cloudflared를 받지 못했어요:', e); return None

def tunnel():
    p = cloudflared_path()
    if not p: log('  → 외부 주소 없이 같은 와이파이에서만 쓸 수 있어요.'); return
    pr = subprocess.Popen([p, 'tunnel', '--no-autoupdate', '--url', f'http://127.0.0.1:{PORT}'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='ignore')
    for line in pr.stdout:
        m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', line)
        if m and not PUBLIC['url']:
            PUBLIC['url'] = m.group(0) + '/?pc=' + KEY
            log('\n================ 연결 주소 ================')
            log(PUBLIC['url'])
            log('QR 코드 창을 열었어요. 휴대폰 카메라로 찍으세요.')
            log('==========================================\n')
            try: webbrowser.open(f'http://127.0.0.1:{PORT}/connect')
            except Exception: pass

if __name__ == '__main__':
    log('가챠 게임 메이커 PC 서버'); log('데이터 폴더:', DATA)
    update_www()
    srv = Srv(('0.0.0.0', PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log(f'이 PC에서 열기: http://127.0.0.1:{PORT}/?pc={KEY}')
    log(f'같은 와이파이 휴대폰: {lan_url()}')
    if '--no-tunnel' not in sys.argv: threading.Thread(target=tunnel, daemon=True).start()
    else:
        try: webbrowser.open(f'http://127.0.0.1:{PORT}/connect')
        except Exception: pass
    log('끄려면 이 창을 닫거나 Ctrl+C')
    try:
        while True: time.sleep(3600)
    except KeyboardInterrupt: pass
